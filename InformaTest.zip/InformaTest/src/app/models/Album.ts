export class Album {
  id: number;
  nome: string;
  ano: int;
  imagem: string;
  artistId: number;
}
