import { Album } from './Album';

export class Artist {
  id: number;
  nome: string;
  albums: Album[];
}
