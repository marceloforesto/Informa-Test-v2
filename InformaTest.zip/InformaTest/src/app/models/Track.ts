export class Track {
  id: number;
  nome: string;
  ano: number;
  estilo: number;
  duracao: number;
}
