import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ArtistsComponent } from './components/artists/artists.component';
import { ArtistDetalheComponent } from './components/artists/artist-detalhe/artist-detalhe.component';
import { TracksComponent } from './components/tracks/tracks.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { PerfilComponent } from './components/perfil/perfil.component';


const routes: Routes = [
  { path: 'tracks', component: TracksComponent },
  { path: 'tracks/:id', component: TracksComponent },
  { path: 'perfil', component: PerfilComponent },
  { path: 'artists', component: ArtistsComponent },
  { path: 'artist/:id', component: ArtistDetalheComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: '**', redirectTo: 'dashboard', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
