import { Component, OnInit, TemplateRef, OnDestroy } from '@angular/core';
import { Track } from '../../models/Track';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { TrackService } from '../../services/track.service';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { ArtistService } from '../../services/artist.service';
import { Artist } from '../../models/Artist';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-tracks',
  templateUrl: './tracks.component.html',
  styleUrls: ['./tracks.component.css']
})
export class TracksComponent implements OnInit, OnDestroy {

  public modalRef: BsModalRef;
  public trackForm: FormGroup;
  public titulo = 'Tracks';
  public trackSelecionado: Track;
  public textSimple: string;
  public profsTracks: Artist[];

  private unsubscriber = new Subject();

  public tracks: Track[];
  public track: Track;
  public msnDeleteTrack: string;
  public modeSave = 'post';

  openModal(template: TemplateRef<any>, trackId: number) {
    this.artistsTracks(template, trackId);
  }

  closeModal() {
    this.modalRef.hide();
  }

  artistsTracks(template: TemplateRef<any>, id: number) {
    this.spinner.show();
    this.artistService.getByTrackId(id)
      .pipe(takeUntil(this.unsubscriber))
      .subscribe((artists: Artist[]) => {
        this.profsTracks = artists;
        this.modalRef = this.modalService.show(template);
      }, (error: any) => {
        this.toastr.error(`erro: ${error}`);
        console.log(error);
      }, () => this.spinner.hide()
    );
  }

  constructor(
    private trackService: TrackService,
    private route: ActivatedRoute,
    private artistService: ArtistService,
    private fb: FormBuilder,
    private modalService: BsModalService,
    private toastr: ToastrService,
    private spinner: NgxSpinnerService
  ) {
    this.criarForm();
  }

  ngOnInit() {
    this.carregarTracks();
  }

  ngOnDestroy(): void {
    this.unsubscriber.next();
    this.unsubscriber.complete();
  }

  criarForm() {
    this.trackForm = this.fb.group({
      id: [0],
      nome: ['', Validators.required],
      ano: ['', Validators.required],
      estilo: ['', Validators.required],
      duracao: ['', Validators.required]
    });
  }

  saveTrack() {
    if (this.trackForm.valid) {
      this.spinner.show();

      if (this.modeSave === 'post') {
        this.track = {...this.trackForm.value};
      } else {
        this.track = {id: this.trackSelecionado.id, ...this.trackForm.value};
      }

      this.trackService[this.modeSave](this.track)
        .pipe(takeUntil(this.unsubscriber))
        .subscribe(
          () => {
            this.carregarTracks();
            this.toastr.success('Track salvo com sucesso!');
          }, (error: any) => {
            this.toastr.error(`Erro: Track não pode ser salvo!`);
            console.error(error);
          }, () => this.spinner.hide()
        );

    }
  }

  carregarTracks() {
    const id = +this.route.snapshot.paramMap.get('id');

    this.spinner.show();
    this.trackService.getAll()
      .pipe(takeUntil(this.unsubscriber))
      .subscribe((tracks: Track[]) => {
        this.tracks = tracks;

        if (id > 0) {
          this.trackSelect(this.tracks.find(track => track.id === id));
        }

        this.toastr.success('Tracks foram carregado com Sucesso!');
      }, (error: any) => {
        this.toastr.error('Tracks não carregados!');
        console.log(error);
      }, () => this.spinner.hide()
    );
  }

  trackSelect(track: Track) {
    this.modeSave = 'put';
    this.trackSelecionado = track;
    this.trackForm.patchValue(track);
  }

  voltar() {
    this.trackSelecionado = null;
  }

}
