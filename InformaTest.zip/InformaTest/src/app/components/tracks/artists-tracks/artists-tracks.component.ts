import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Artist } from 'src/app/models/Artist';
import { Util } from '../../../util/util';
import { Album } from 'src/app/models/Album';
import { Router } from '@angular/router';

@Component({
  selector: 'app-artists-tracks',
  templateUrl: './artists-tracks.component.html',
  styleUrls: ['./artists-tracks.component.css']
})
export class ArtistsTracksComponent implements OnInit {

  @Input() public artists: Artist[];
  @Output() closeModal = new EventEmitter();

  constructor(private router: Router) { }

  ngOnInit() {
  }

  albumConcat(albums: Album[]) {
    return Util.nomeConcat(albums);
  }

  artistSelect(prof: Artist) {
    this.closeModal.emit(null);
    this.router.navigate(['/artist', prof.id]);
  }

}
