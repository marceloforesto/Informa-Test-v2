import { Component, OnInit, TemplateRef, OnDestroy } from '@angular/core';
import { Artist } from '../../models/Artist';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { Subject } from 'rxjs';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ArtistService } from '../../services/artist.service';
import { takeUntil } from 'rxjs/operators';
import { Util } from '../../util/util';
import { Album } from '../../models/Album';
import { Router } from '@angular/router';
import { Track } from '../../models/Track';
import { TrackService } from '../../services/track.service';

@Component({
  selector: 'app-artists',
  templateUrl: './artists.component.html',
  styleUrls: ['./artists.component.css']
})
export class ArtistsComponent implements OnInit, OnDestroy {

  public titulo = 'Artists';
  public artistSelecionado: Artist;
  private unsubscriber = new Subject();

  public artists: Artist[];

  constructor(
    private router: Router,
    private artistService: ArtistService,
    private toastr: ToastrService,
    private spinner: NgxSpinnerService) {}

  carregarArtists() {
    this.spinner.show();
    this.artistService.getAll()
      .pipe(takeUntil(this.unsubscriber))
      .subscribe((artists: Artist[]) => {
        this.artists = artists;
        this.toastr.success('Artists foram carregado com Sucesso!');
      }, (error: any) => {
        this.toastr.error('Artists não carregados!');
        console.log(error);
      }, () => this.spinner.hide()
    );
  }

  ngOnInit() {
    this.carregarArtists();
  }

  ngOnDestroy(): void {
    this.unsubscriber.next();
    this.unsubscriber.complete();
  }

  albumConcat(albums: Album[]) {
    return Util.nomeConcat(albums);
  }

}
