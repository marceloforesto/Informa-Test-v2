import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Track } from 'src/app/models/Track';
import { Util } from 'src/app/util/util';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tracks-artists',
  templateUrl: './tracks-artists.component.html',
  styleUrls: ['./tracks-artists.component.css']
})
export class TracksArtistsComponent implements OnInit {

  @Input() public tracks: Track[];
  @Output() closeModal = new EventEmitter();

  constructor(private router: Router) { }

  ngOnInit() {
  }

  trackSelect(id: number) {
    this.closeModal.emit(null);
    this.router.navigate(['/tracks', id]);
  }

}
