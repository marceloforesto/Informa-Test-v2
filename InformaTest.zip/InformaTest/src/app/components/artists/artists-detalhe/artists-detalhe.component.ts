import { Component, OnInit, OnDestroy, TemplateRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ArtistService } from 'src/app/services/artist.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Artist } from 'src/app/models/Artist';
import { TrackService } from 'src/app/services/track.service';
import { Track } from 'src/app/models/Track';

@Component({
  selector: 'app-artist-detalhe',
  templateUrl: './artist-detalhe.component.html',
  styleUrls: ['./artist-detalhe.component.css']
})
export class ArtistDetalheComponent implements OnInit, OnDestroy {

  public modalRef: BsModalRef;
  public artistSelecionado: Artist;
  public titulo = '';
  public tracksProfs: Track[];
  private unsubscriber = new Subject();

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private artistService: ArtistService,
    private trackService: TrackService,
    private modalService: BsModalService,
    private toastr: ToastrService,
    private spinner: NgxSpinnerService
  ) { }

  openModal(template: TemplateRef<any>, trackId: number) {
    this.tracksArtists(template, trackId);
  }

  closeModal() {
    this.modalRef.hide();
  }

  tracksArtists(template: TemplateRef<any>, id: number) {
    this.spinner.show();
    this.trackService.getByAlbumId(id)
      .pipe(takeUntil(this.unsubscriber))
      .subscribe((tracks: Track[]) => {
        this.tracksProfs = tracks;
        this.modalRef = this.modalService.show(template);
      }, (error: any) => {
        this.toastr.error(`erro: ${error}`);
        console.log(error);
      }, () => this.spinner.hide()
    );
  }

  ngOnInit() {
    this.spinner.show();
    this.carregarArtist();
  }

  carregarArtist() {
    const profId = +this.route.snapshot.paramMap.get('id');
    this.artistService.getById(profId)
      .pipe(takeUntil(this.unsubscriber))
      .subscribe((artist: Artist) => {
        this.artistSelecionado = artist;
        this.titulo = 'Artist: ' + this.artistSelecionado.id;
        this.toastr.success('Artist carregado com Sucesso!');
      }, (error: any) => {
        this.toastr.error('Artist não carregados!');
        console.log(error);
      }, () => this.spinner.hide()
    );
  }

  voltar() {
    this.router.navigate(['/artists']);
  }

  ngOnDestroy(): void {
    this.unsubscriber.next();
    this.unsubscriber.complete();
  }

}
