import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Artist } from '../models/Artist';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ArtistService {

  baseURL = `${environment.mainUrlAPI}artist`;

  constructor(private http: HttpClient) { }

  getAll(): Observable<Artist[]> {
    return this.http.get<Artist[]>(this.baseURL);
  }

  getById(id: number): Observable<Artist> {
    return this.http.get<Artist>(`${this.baseURL}/${id}`);
  }

  getByTrackId(id: number): Observable<Artist[]> {
    return this.http.get<Artist[]>(`${this.baseURL}/ByTrack/${id}`);
  }

  post(artist: Artist) {
    return this.http.post(this.baseURL, Artist);
  }

  put(artist: Artist) {
    return this.http.put(`${this.baseURL}/${artist.id}`, Artist);
  }

  delete(id: number) {
    return this.http.delete(`${this.baseURL}/${id}`);
  }

}
