import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Track } from '../models/Track';

import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TrackService {

  baseURL = `${environment.mainUrlAPI}track`;

  constructor(private http: HttpClient) { }

  getAll(): Observable<Track[]> {
    return this.http.get<Track[]>(this.baseURL);
  }

  getById(id: number): Observable<Track> {
    return this.http.get<Track>(`${this.baseURL}/${id}`);
  }

  getByAlbumId(id: number): Observable<Track[]> {
    return this.http.get<Track[]>(`${this.baseURL}/ByAlbum/${id}`);
  }

  post(track: Track) {
    return this.http.post(this.baseURL, track);
  }

  put(track: Track) {
    return this.http.put(`${this.baseURL}/${track.id}`, track);
  }

  delete(id: number) {
    return this.http.delete(`${this.baseURL}/${id}`);
  }

}
